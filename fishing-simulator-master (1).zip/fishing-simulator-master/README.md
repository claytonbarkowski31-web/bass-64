# fishing-simulator

[![Gitter](https://badges.gitter.im/鱼丸蛋蛋/fish.svg)](https://gitter.im/鱼丸蛋蛋/fish?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)

## 鱼丸蛋蛋旗下首款作品

> 钓鱼模拟器

一个很虐又让你忍不住想玩的游戏

## 目录结构

- cocos 游戏客户端代码
- koa 游戏服务端代码

## 在线聊天

[鱼丸蛋蛋](https://gitter.im/鱼丸蛋蛋/fish?utm_source=share-link&utm_medium=link&utm_campaign=share-link)

## 开发计划

截止日期为地球毁灭，只要地球在，我们就在！

## 开发语言

- cocos 游戏客户端主要用cocos creater框架，语言是js/ts。
- koa 服务端主要用的框架是koa，语言是nodejs。

## 开发者文档

- [koa](./koa/README.md)

## 什么？你都不会，没关系，乐在参与！
