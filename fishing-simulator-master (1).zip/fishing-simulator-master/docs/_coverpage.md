# 钓鱼大叔 API

> 钓鱼大叔 NodeJS 版 API

- 全部接口已升级到最新
- 具备登录接口,多达100多个接口
- 更完善的文档


[GitHub](https://github.com/pengqiangsheng/fishing-simulator)
[Get Started](#Uncle-Fish-Games)

<!-- ![color](#ffffff) -->