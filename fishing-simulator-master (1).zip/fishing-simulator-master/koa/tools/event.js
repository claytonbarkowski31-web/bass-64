const EventEmitter = require('events').EventEmitter

module.exports =  new EventEmitter()