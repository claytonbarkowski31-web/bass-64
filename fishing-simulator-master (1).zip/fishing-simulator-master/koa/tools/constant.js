module.exports = {
  SECRET: 'pqs-secret',
  CAT: 'cat',
  CLEARCACHE: 'clearCache'
}
